'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Mail, User } from 'lucide-react';

interface ContactInfoProps {
  name: string;
  email: string;
}

export function ContactInfo({ name, email }: ContactInfoProps) {
  const [revealed, setRevealed] = useState(false);

  if (!revealed) {
    return (
      <Button onClick={() => setRevealed(true)} className="w-full" variant="default">
        Reveal Contact Info
      </Button>
    );
  }

  return (
    <Card className="bg-secondary">
        <CardHeader>
            <CardTitle className="text-lg">Contact Information</CardTitle>
        </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-3">
          <User className="w-5 h-5 text-muted-foreground" />
          <span className="font-medium">{name}</span>
        </div>
        <div className="flex items-center gap-3">
          <Mail className="w-5 h-5 text-muted-foreground" />
          <a href={`mailto:${email}`} className="font-medium text-primary hover:underline">
            {email}
          </a>
        </div>
      </CardContent>
    </Card>
  );
}
