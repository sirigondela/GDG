'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, Menu, Search, SearchSlash, Bot, PlusCircle, List } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { cn } from '@/lib/utils';
import React from 'react';

const navLinks = [
  { href: '/lost', label: 'Lost Items', icon: SearchSlash },
  { href: '/found', label: 'Found Items', icon: Search },
  { href: '/matching', label: 'AI Matcher', icon: Bot },
  { href: '/reported-items', label: 'Reported Items', icon: List },
];

export function Header() {
  const pathname = usePathname();
  const [isSheetOpen, setIsSheetOpen] = React.useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <Link href="/" className="mr-6 flex items-center space-x-2">
          <Home className="h-6 w-6 text-primary" />
          <span className="font-bold sm:inline-block font-headline">CampusFind</span>
        </Link>
        <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                'transition-colors hover:text-foreground/80',
                pathname === link.href ? 'text-foreground' : 'text-foreground/60'
              )}
            >
              {link.label}
            </Link>
          ))}
        </nav>
        <div className="flex flex-1 items-center justify-end space-x-2">
          <Button asChild className="hidden sm:inline-flex bg-accent hover:bg-accent/90 text-accent-foreground">
            <Link href="/lost/new">Report Lost</Link>
          </Button>
          <Button asChild className="hidden sm:inline-flex">
            <Link href="/found/new">Submit Found</Link>
          </Button>

          <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle Navigation</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <Link href="/" className="mr-6 flex items-center space-x-2 mb-6" onClick={() => setIsSheetOpen(false)}>
                <Home className="h-6 w-6 text-primary" />
                <span className="font-bold font-headline">CampusFind</span>
              </Link>
              <div className="flex flex-col space-y-3">
                {navLinks.map(({ href, label, icon: Icon }) => (
                  <Link
                    key={href}
                    href={href}
                    onClick={() => setIsSheetOpen(false)}
                    className={cn(
                      'flex items-center gap-3 rounded-md p-2 text-sm font-medium hover:bg-muted',
                      pathname === href ? 'bg-muted' : ''
                    )}
                  >
                    <Icon className="h-5 w-5" />
                    {label}
                  </Link>
                ))}
                <div className="border-t pt-4 space-y-3">
                    <Button asChild className="w-full justify-start bg-accent hover:bg-accent/90 text-accent-foreground" onClick={() => setIsSheetOpen(false)}>
                        <Link href="/lost/new"><PlusCircle className="mr-2 h-5 w-5"/> Report Lost Item</Link>
                    </Button>
                    <Button asChild className="w-full justify-start" onClick={() => setIsSheetOpen(false)}>
                        <Link href="/found/new"><PlusCircle className="mr-2 h-5 w-5"/> Submit Found Item</Link>
                    </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
