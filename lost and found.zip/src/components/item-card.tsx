import Image from 'next/image';
import Link from 'next/link';
import { formatDistanceToNow } from 'date-fns';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { Item } from '@/lib/types';
import { MapPin } from 'lucide-react';
import { PlaceHolderImages } from '@/lib/placeholder-images';

interface ItemCardProps {
  item: Item;
}

export function ItemCard({ item }: ItemCardProps) {
  const defaultImage = PlaceHolderImages.find(p => p.id === 'default');
  const itemImage = item.imageUrl ? { url: item.imageUrl, hint: item.imageHint || 'item' } : { url: defaultImage?.imageUrl, hint: defaultImage?.imageHint };

  return (
    <Card className="flex flex-col h-full overflow-hidden transition-shadow duration-300 hover:shadow-lg">
      <CardHeader className="p-0">
        <div className="relative h-48 w-full">
          {itemImage.url && (
            <Image
              src={itemImage.url}
              alt={item.name}
              fill
              className="object-cover"
              data-ai-hint={itemImage.hint}
            />
          )}
        </div>
      </CardHeader>
      <CardContent className="p-4 flex-grow">
        <div className="flex justify-between items-start mb-2">
            <Badge variant={item.type === 'lost' ? 'destructive' : 'default'} className="capitalize bg-accent text-accent-foreground">
              {item.type}
            </Badge>
            <span className="text-xs text-muted-foreground">
              {formatDistanceToNow(new Date(item.date), { addSuffix: true })}
            </span>
        </div>
        <CardTitle className="font-headline text-lg mb-2 line-clamp-1">{item.name}</CardTitle>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
          {item.description}
        </p>
        <div className="flex items-center text-sm text-muted-foreground">
          <MapPin className="w-4 h-4 mr-2" />
          <span>{item.location}</span>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Link href={`/${item.type}/${item.id}`} className="w-full">
          <div className="text-sm text-primary hover:underline w-full text-right">View Details &rarr;</div>
        </Link>
      </CardFooter>
    </Card>
  );
}
