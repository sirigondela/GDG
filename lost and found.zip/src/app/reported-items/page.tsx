
'use client';

import { getItems } from '@/lib/data';
import { ItemCard } from '@/components/item-card';
import { useEffect, useState } from 'react';
import type { Item } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { List } from 'lucide-react';

function ItemSkeleton() {
    return (
        <div className="flex flex-col space-y-3">
            <Skeleton className="h-48 w-full rounded-xl" />
            <div className="space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
            </div>
        </div>
    )
}

export default function ReportedItemsPage() {
    const [allItems, setAllItems] = useState<Item[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function loadItems() {
            setLoading(true);
            const items = await getItems();
            setAllItems(items);
            setLoading(false);
        }
        loadItems();
    }, []);

    const lostItems = allItems.filter(item => item.type === 'lost');
    const foundItems = allItems.filter(item => item.type === 'found');

    const renderItemList = (items: Item[], type: 'lost' | 'found') => {
        const emptyStateMessages = {
            lost: {
                title: "No lost items reported yet.",
                subtitle: "Be the first one to report a lost item!"
            },
            found: {
                title: "No found items submitted yet.",
                subtitle: "Found something? Be the first to submit it!"
            }
        };

        if (loading) {
            return (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                    {[...Array(4)].map((_, i) => <ItemSkeleton key={i} />)}
                </div>
            );
        }

        if (items.length > 0) {
            return (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                    {items.map((item) => (
                        <ItemCard key={item.id} item={item} />
                    ))}
                </div>
            );
        }

        return (
            <div className="text-center py-16 border-2 border-dashed rounded-lg">
                <h2 className="text-xl font-semibold text-muted-foreground">{emptyStateMessages[type].title}</h2>
                <p className="text-muted-foreground mt-2">{emptyStateMessages[type].subtitle}</p>
            </div>
        );
    };

  return (
    <div className="container mx-auto px-4 md:px-6 py-8">
      <div className="flex items-center mb-8 gap-3">
        <List className="h-8 w-8" />
        <h1 className="text-3xl font-bold font-headline">All Reported Items</h1>
      </div>
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-3 max-w-md">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="lost">Lost</TabsTrigger>
            <TabsTrigger value="found">Found</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="mt-6">
            {renderItemList(allItems, 'lost')}
        </TabsContent>
        <TabsContent value="lost" className="mt-6">
            {renderItemList(lostItems, 'lost')}
        </TabsContent>
        <TabsContent value="found" className="mt-6">
            {renderItemList(foundItems, 'found')}
        </TabsContent>
        </Tabs>
    </div>
  );
}
