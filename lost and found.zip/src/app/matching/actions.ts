'use server';

import { z } from 'zod';
import { matchLostAndFoundItems } from '@/ai/flows/match-lost-and-found-items';

export const matchingSchema = z.object({
  lostItemDescription: z.string().min(5, 'Lost item description is too short.'),
  lostItemLocation: z.string().min(3, 'Lost item location is required.'),
  foundItemDescription: z.string().min(5, 'Found item description is too short.'),
  foundItemLocation: z.string().min(3, 'Found item location is required.'),
});

export type MatchingResult = {
  matchLikelihood: string;
  reasoning: string;
}

export async function getMatchLikelihoodAction(data: z.infer<typeof matchingSchema>) {
    const validation = matchingSchema.safeParse(data);

    if (!validation.success) {
        return {
            errors: validation.error.flatten().fieldErrors,
        };
    }

    try {
        const result = await matchLostAndFoundItems(validation.data);
        return { data: result };
    } catch (error) {
        console.error(error);
        return { error: 'Failed to get match likelihood from AI.' };
    }
}
