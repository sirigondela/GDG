'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { getMatchLikelihoodAction, matchingSchema, type MatchingResult } from './actions';
import { useTransition, useState } from 'react';
import { Bot, Loader2, Search, SearchSlash } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

type MatchingFormValues = z.infer<typeof matchingSchema>;

export default function MatchingPage() {
  const { toast } = useToast();
  const [isPending, startTransition] = useTransition();
  const [result, setResult] = useState<MatchingResult | null>(null);

  const form = useForm<MatchingFormValues>({
    resolver: zodResolver(matchingSchema),
    defaultValues: {
        lostItemDescription: '',
        lostItemLocation: '',
        foundItemDescription: '',
        foundItemLocation: '',
    },
  });

  function onSubmit(values: MatchingFormValues) {
    setResult(null);
    startTransition(async () => {
      const response = await getMatchLikelihoodAction(values);
      if (response?.errors) {
        toast({
            variant: "destructive",
            title: "Validation Error",
            description: "Please check the form for errors and try again."
        });
      } else if (response?.error) {
        toast({
            variant: "destructive",
            title: "AI Error",
            description: response.error,
        });
      } else if (response?.data) {
        setResult(response.data);
      }
    });
  }

  const likelihoodValue = result ? parseInt(result.matchLikelihood.replace('%', '')) : 0;
  
  return (
    <div className="container mx-auto px-4 md:px-6 py-8">
      <div className="text-center max-w-3xl mx-auto mb-8">
        <h1 className="text-3xl font-bold font-headline mb-2 flex items-center justify-center gap-3"><Bot /> AI Matching Tool</h1>
        <p className="text-muted-foreground">
            Enter the details of a lost item and a found item below. Our AI will analyze the information and provide a likelihood of them being a match.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <Card className="lg:col-span-2">
          <CardContent className="p-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                <div className="grid md:grid-cols-2 gap-8">
                    {/* Lost Item Column */}
                    <div className="space-y-6">
                        <div className="flex items-center gap-3">
                            <SearchSlash className="w-6 h-6 text-accent"/>
                            <h3 className="text-xl font-semibold font-headline">Lost Item Details</h3>
                        </div>
                        <FormField
                            control={form.control}
                            name="lostItemDescription"
                            render={({ field }) => (
                            <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                <Textarea placeholder="e.g., Black Jansport backpack with a laptop inside." {...field} className="min-h-[120px]"/>
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="lostItemLocation"
                            render={({ field }) => (
                            <FormItem>
                                <FormLabel>Location Lost</FormLabel>
                                <FormControl>
                                <Input placeholder="e.g., Near the library" {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                            )}
                        />
                    </div>
                    {/* Found Item Column */}
                    <div className="space-y-6">
                        <div className="flex items-center gap-3">
                            <Search className="w-6 h-6 text-primary"/>
                            <h3 className="text-xl font-semibold font-headline">Found Item Details</h3>
                        </div>
                        <FormField
                            control={form.control}
                            name="foundItemDescription"
                            render={({ field }) => (
                            <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                <Textarea placeholder="e.g., Found a backpack, seems to have a computer." {...field} className="min-h-[120px]"/>
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="foundItemLocation"
                            render={({ field }) => (
                            <FormItem>
                                <FormLabel>Location Found</FormLabel>
                                <FormControl>
                                <Input placeholder="e.g., Main Quad bench" {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                            )}
                        />
                    </div>
                </div>
                <Button type="submit" disabled={isPending} className="w-full sm:w-auto">
                  {isPending ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Analyzing...</> : 'Check for Match'}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {(isPending || result) && (
            <div className="lg:col-span-2">
                <Card>
                    <CardHeader>
                        <CardTitle>AI Analysis Result</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {isPending ? (
                            <div className="flex flex-col items-center justify-center p-8 space-y-3">
                                <Loader2 className="w-8 h-8 animate-spin text-primary"/>
                                <p className="text-muted-foreground">Our AI is analyzing the details...</p>
                            </div>
                        ) : result && (
                            <div className="space-y-4">
                                <div>
                                    <div className="flex justify-between items-center mb-1">
                                        <FormLabel>Match Likelihood</FormLabel>
                                        <span className="font-bold text-primary text-lg">{result.matchLikelihood}</span>
                                    </div>
                                    <Progress value={likelihoodValue} className="h-3"/>
                                </div>
                                <div>
                                    <FormLabel>Reasoning</FormLabel>
                                    <p className="text-sm text-muted-foreground bg-secondary p-3 rounded-md mt-1">{result.reasoning}</p>
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>
        )}
      </div>
    </div>
  );
}
