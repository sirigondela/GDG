
'use server';

import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { Item } from '@/lib/types';
import { addItem } from '@/lib/server-data';

// This is not the full type, but it's what we need for the function signature.
type LostItemData = Omit<Item, 'id' | 'date' | 'type'>;

export async function addLostItemAction(data: LostItemData) {
  const newItem = await addItem({
    ...data,
    type: 'lost',
  });

  revalidatePath('/lost');
  revalidatePath('/reported-items');
  revalidatePath('/');


  redirect(`/lost/${newItem.id}`);
}
