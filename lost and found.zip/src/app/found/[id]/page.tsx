
'use client';

import { getItem } from '@/lib/data';
import { notFound } from 'next/navigation';
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar, MapPin, Tag } from 'lucide-react';
import { format } from 'date-fns';
import { ContactInfo } from '@/components/contact-info';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import type { Item } from '@/lib/types';
import { useEffect, useState, use } from 'react';
import { Skeleton } from '@/components/ui/skeleton';

export default function FoundItemDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [item, setItem] = useState<Item | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadItem() {
      if (!id) return;
      setLoading(true);
      const fetchedItem = await getItem(id);
      
      if (fetchedItem && fetchedItem.type === 'found') {
        setItem(fetchedItem);
      }
      setLoading(false);
    }
    loadItem();
  }, [id]);

  if (loading) {
      return (
          <div className="container mx-auto px-4 md:px-6 py-8">
              <div className="grid md:grid-cols-5 gap-8">
                  <div className="md:col-span-3 space-y-4">
                      <Skeleton className="h-96 w-full rounded-lg"/>
                      <Skeleton className="h-24 w-full rounded-lg"/>
                  </div>
                  <div className="md:col-span-2 space-y-6">
                    <Skeleton className="h-40 w-full rounded-lg"/>
                    <Skeleton className="h-32 w-full rounded-lg"/>
                  </div>
              </div>
          </div>
      )
  }

  if (!item) {
    notFound();
  }

  const defaultImage = PlaceHolderImages.find(p => p.id === 'default');
  const itemImage = item.imageUrl ? { url: item.imageUrl, hint: item.imageHint || 'item' } : { url: defaultImage?.imageUrl, hint: defaultImage?.imageHint };

  return (
    <div className="container mx-auto px-4 md:px-6 py-8">
      <div className="grid md:grid-cols-5 gap-8">
        <div className="md:col-span-3">
          <div className="relative h-96 w-full rounded-lg overflow-hidden border shadow-sm mb-4">
            {itemImage.url && (
                <Image
                    src={itemImage.url}
                    alt={item.name}
                    fill
                    className="object-cover"
                    data-ai-hint={itemImage.hint}
                />
            )}
          </div>
          <Card>
            <CardHeader>
              <CardTitle className="font-headline text-2xl">{item.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{item.description}</p>
            </CardContent>
          </Card>
        </div>
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Item Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div className="flex items-center gap-3">
                <Tag className="w-5 h-5 text-muted-foreground" />
                <Badge className="capitalize bg-primary/80 text-primary-foreground">{item.type}</Badge>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-muted-foreground" />
                <span>Found at <span className="font-semibold">{item.location}</span></span>
              </div>
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-muted-foreground" />
                <span>Submitted on {format(new Date(item.date), 'MMMM d, yyyy')}</span>
              </div>
            </CardContent>
          </Card>
          <ContactInfo name={item.contactName} email={item.contactEmail} />
        </div>
      </div>
    </div>
  );
}
