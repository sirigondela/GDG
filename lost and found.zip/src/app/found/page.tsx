
'use client';

import { getItems } from '@/lib/data';
import { ItemCard } from '@/components/item-card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { PlusCircle } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { Item } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';

function ItemSkeleton() {
    return (
        <div className="flex flex-col space-y-3">
            <Skeleton className="h-48 w-full rounded-xl" />
            <div className="space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
            </div>
        </div>
    )
}

export default function FoundItemsPage() {
    const [foundItems, setFoundItems] = useState<Item[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function loadItems() {
            setLoading(true);
            const items = await getItems('found');
            setFoundItems(items);
            setLoading(false);
        }
        loadItems();
    }, []);

  return (
    <div className="container mx-auto px-4 md:px-6 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold font-headline">Found Items</h1>
        <Button asChild>
          <Link href="/found/new">
            <PlusCircle className="mr-2 h-4 w-4" />
            Submit a Found Item
          </Link>
        </Button>
      </div>
      {loading ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {[...Array(4)].map((_, i) => <ItemSkeleton key={i} />)}
        </div>
      ) : foundItems.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {foundItems.map((item) => (
            <ItemCard key={item.id} item={item} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 border-2 border-dashed rounded-lg">
          <h2 className="text-xl font-semibold text-muted-foreground">No found items submitted yet.</h2>
          <p className="text-muted-foreground mt-2">Found something? Be the first to submit it!</p>
        </div>
      )}
    </div>
  );
}
