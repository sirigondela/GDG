
'use server';

import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { generateItemDescription } from '@/ai/flows/generate-item-description';
import { Item } from '@/lib/types';
import { addItem } from '@/lib/server-data';

type FoundItemData = Omit<Item, 'id' | 'date' | 'type'>;

export async function addFoundItemAction(data: FoundItemData) {
  const newItem = await addItem({
    ...data,
    type: 'found',
  });

  revalidatePath('/found');
  revalidatePath('/reported-items');
  revalidatePath('/');

  redirect(`/found/${newItem.id}`);
}

export async function generateDescriptionAction(photoDataUri: string) {
    if (!photoDataUri) {
        return { error: 'No photo provided.' };
    }
    try {
        const result = await generateItemDescription({ photoDataUri });
        return { description: result.itemDescription };
    } catch (error) {
        console.error(error);
        return { error: 'Failed to generate description.' };
    }
}
