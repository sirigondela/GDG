import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FoundItemForm } from './found-item-form';

export default function SubmitFoundItemPage() {
  return (
    <div className="container mx-auto px-4 md:px-6 py-8 max-w-3xl">
      <Card>
        <CardHeader>
          <CardTitle className="text-3xl font-bold font-headline">Submit a Found Item</CardTitle>
          <CardDescription>
            Thank you for helping! Fill out the form below to submit an item you've found.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <FoundItemForm />
        </CardContent>
      </Card>
    </div>
  );
}
