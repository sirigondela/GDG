'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { addFoundItemAction, generateDescriptionAction } from './actions';
import { useTransition, useState } from 'react';
import { Bot, Image as ImageIcon, Loader2, X } from 'lucide-react';
import Image from 'next/image';

const foundItemSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters.'),
  description: z.string().min(10, 'Description must be at least 10 characters.'),
  location: z.string().min(3, 'Location must be at least 3 characters.'),
  contactName: z.string().min(2, 'Contact name is required.'),
  contactEmail: z.string().email('Please enter a valid email.'),
  imageUrl: z.string().optional(),
  imageHint: z.string().optional(),
});


type FoundItemFormValues = z.infer<typeof foundItemSchema>;

export function FoundItemForm() {
  const { toast } = useToast();
  const [isSubmitPending, startSubmitTransition] = useTransition();
  const [isGenerating, startGeneratingTransition] = useTransition();
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const form = useForm<FoundItemFormValues>({
    resolver: zodResolver(foundItemSchema),
    defaultValues: {
      name: '',
      description: '',
      location: '',
      contactName: '',
      contactEmail: '',
    },
  });

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
        form.setValue('imageUrl', reader.result as string, { shouldValidate: true });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerateDescription = async () => {
    const photoDataUri = form.getValues('imageUrl');
    if (!photoDataUri) {
      toast({
        variant: 'destructive',
        title: 'No Image Selected',
        description: 'Please upload an image first to generate a description.',
      });
      return;
    }

    startGeneratingTransition(async () => {
      const result = await generateDescriptionAction(photoDataUri);
      if (result.error) {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: result.error,
        });
      } else if (result.description) {
        form.setValue('description', result.description, { shouldValidate: true });
        toast({
          title: 'Description Generated',
          description: 'The AI-generated description has been added.',
        });
      }
    });
  };

  function onSubmit(values: FoundItemFormValues) {
    startSubmitTransition(() => {
        addFoundItemAction(values).then(() => {
          toast({
              title: "Item Submitted",
              description: "Thank you! The found item has been successfully submitted.",
          });
        });
    });
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <FormField
          control={form.control}
          name="imageUrl"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Item Image (Optional)</FormLabel>
              <FormControl>
                <div>
                  <Input type="file" accept="image/*" className="hidden" id="image-upload" onChange={handleImageChange} />
                  <label htmlFor="image-upload" className="cursor-pointer">
                    {imagePreview ? (
                      <div className="relative w-full h-64 rounded-md border-2 border-dashed flex items-center justify-center text-muted-foreground overflow-hidden">
                        <Image src={imagePreview} alt="Preview" fill className="object-contain" />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          className="absolute top-2 right-2 z-10"
                          onClick={(e) => {
                            e.preventDefault();
                            setImagePreview(null);
                            form.setValue('imageUrl', undefined);
                          }}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <div className="w-full h-40 rounded-md border-2 border-dashed flex flex-col items-center justify-center text-muted-foreground hover:bg-muted/50 transition-colors">
                        <ImageIcon className="w-10 h-10 mb-2" />
                        <span>Click or drag to upload an image</span>
                      </div>
                    )}
                  </label>
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Item Name</FormLabel>
              <FormControl>
                <Input placeholder="e.g., Blue iPhone 13, Black Backpack" {...field} />
              </FormControl>
              <FormDescription>A short, descriptive name for the item.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Provide details like brand, color, size, and any unique features."
                  className="resize-y min-h-[100px]"
                  {...field}
                />
              </FormControl>
              <FormMessage />
              <div className="flex justify-end pt-2">
                <Button type="button" variant="ghost" size="sm" onClick={handleGenerateDescription} disabled={isGenerating || !imagePreview}>
                  {isGenerating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Bot className="mr-2 h-4 w-4" />}
                  Generate with AI
                </Button>
              </div>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="location"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Location Found</FormLabel>
              <FormControl>
                <Input placeholder="e.g., Library, Student Union, Main Quad" {...field} />
              </FormControl>
              <FormDescription>Where did you find this item?</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="space-y-2">
            <h3 className="text-lg font-medium">Your Contact Information</h3>
            <p className="text-sm text-muted-foreground">This will be shared with the person who claims the item.</p>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <FormField
              control={form.control}
              name="contactName"
              render={({ field }) => (
              <FormItem>
                  <FormLabel>Your Name</FormLabel>
                  <FormControl>
                  <Input placeholder="Jane Doe" {...field} />
                  </FormControl>
                  <FormMessage />
              </FormItem>
              )}
          />
          <FormField
              control={form.control}
              name="contactEmail"
              render={({ field }) => (
              <FormItem>
                  <FormLabel>Your Email</FormLabel>
                  <FormControl>
                  <Input type="email" placeholder="jane.doe@campus.edu" {...field} />
                  </FormControl>
                  <FormMessage />
              </FormItem>
              )}
          />
        </div>

        <Button type="submit" disabled={isSubmitPending} className="w-full sm:w-auto">
          {isSubmitPending ? 'Submitting...' : 'Submit Found Item'}
        </Button>
      </form>
    </Form>
  );
}
