import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowRight, Bot, Search, SearchSlash } from 'lucide-react';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="flex flex-col items-center">
      <section className="w-full py-20 md:py-32 lg:py-40 bg-card border-b">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tighter mb-4 font-headline">
            Welcome to CampusFind
          </h1>
          <p className="max-w-2xl mx-auto text-lg md:text-xl text-muted-foreground mb-8">
            The smart way to reconnect with your lost items on campus. Report lost items, submit found ones, and let our AI help you find a match.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
              <Link href="/lost/new">
                I Lost Something
              </Link>
            </Button>
            <Button asChild size="lg" variant="default">
              <Link href="/found/new">I Found Something</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="w-full py-16 md:py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid gap-8 md:grid-cols-3">
            <Card className="flex flex-col">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="bg-secondary p-3 rounded-full">
                    <SearchSlash className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="font-headline">Report Lost Items</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <CardDescription>
                  Misplaced something? Quickly post a report with a description and location. Our community and AI will help you track it down.
                </CardDescription>
              </CardContent>
              <div className="p-6 pt-0">
                <Button asChild variant="outline">
                  <Link href="/lost">View Lost Items <ArrowRight className="ml-2" /></Link>
                </Button>
              </div>
            </Card>

            <Card className="flex flex-col">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="bg-secondary p-3 rounded-full">
                    <Search className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="font-headline">Submit Found Items</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <CardDescription>
                  Found an item on campus? Be a hero. Submit its details and an optional photo to help it find its way back to the owner.
                </CardDescription>
              </CardContent>
              <div className="p-6 pt-0">
                <Button asChild variant="outline">
                  <Link href="/found">Browse Found Items <ArrowRight className="ml-2" /></Link>
                </Button>
              </div>
            </Card>
            
            <Card className="flex flex-col">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="bg-secondary p-3 rounded-full">
                    <Bot className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="font-headline">AI-Powered Matching</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <CardDescription>
                  Our intelligent system analyzes descriptions and locations to suggest potential matches between lost and found items, increasing the chances of a reunion.
                </CardDescription>
              </CardContent>
              <div className="p-6 pt-0">
                <Button asChild variant="outline">
                  <Link href="/matching">Try the Matcher <ArrowRight className="ml-2" /></Link>
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
