
'use client';
import type { Item } from './types';
import { getItems as getItemsFromServer, getItem as getItemFromServer } from './server-data';

export async function getItems(type?: 'lost' | 'found'): Promise<Item[]> {
  // This function can be called on the client.
  // For simplicity, we'll just call the server function.
  // In a real app, you might have client-side caching here.
  return getItemsFromServer(type);
}

export async function getItem(id: string): Promise<Item | undefined> {
  return getItemFromServer(id);
}
