export interface Item {
  id: string;
  type: 'lost' | 'found';
  name: string;
  description: string;
  location: string;
  date: string; // Using string to be easily serializable
  imageUrl?: string;
  imageHint?: string;
  contactName: string;
  contactEmail: string;
}
