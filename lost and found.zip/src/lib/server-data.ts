
'use server';
import type { Item } from './types';
import { unstable_noStore as noStore } from 'next/cache';
import fs from 'fs/promises';
import path from 'path';

// In a real application, this would be a database.
// For this prototype, we're using a simple file-based storage.
const itemsFilePath = path.join(process.cwd(), 'src', 'lib', 'items.json');

async function readItems(): Promise<Item[]> {
  try {
    const data = await fs.readFile(itemsFilePath, 'utf-8');
    return JSON.parse(data) as Item[];
  } catch (error) {
    // If the file doesn't exist, return the initial items and create the file.
    console.log('items.json not found, creating with initial data.');
    await writeItems(initialItems);
    return initialItems;
  }
}

async function writeItems(items: Item[]): Promise<void> {
  await fs.writeFile(itemsFilePath, JSON.stringify(items, null, 2), 'utf-8');
}


const initialItems: Item[] = [
  {
    id: '1',
    type: 'found',
    name: 'Black Backpack',
    description: 'A black Jansport backpack found near the library entrance. Contains a laptop and a notebook.',
    location: 'Library Entrance',
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    imageUrl: 'https://picsum.photos/seed/backpack/600/400',
    imageHint: 'gray backpack',
    contactName: 'Jane Doe',
    contactEmail: 'jane.doe@campus.edu',
  },
  {
    id: '2',
    type: 'lost',
    name: 'Car Keys',
    description: 'A set of Toyota car keys with a red keychain. Last seen in the student union building.',
    location: 'Student Union',
    date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    imageUrl: 'https://picsum.photos/seed/keys/600/400',
    imageHint: 'keys on table',
    contactName: 'John Smith',
    contactEmail: 'john.smith@campus.edu',
  },
  {
    id: '3',
    type: 'found',
    name: 'iPhone 13',
    description: 'A blue iPhone 13 in a clear case. Found on a bench in the main quad.',
    location: 'Main Quad',
    date: new Date().toISOString(),
    imageUrl: 'https://picsum.photos/seed/phone/600/400',
    imageHint: 'smartphone screen',
    contactName: 'Admin',
    contactEmail: 'admin@campus.edu',
  },
  {
    id: '4',
    type: 'lost',
    name: 'Brown Leather Wallet',
    description: 'Lost a brown leather wallet, likely in the cafeteria. Contains a student ID and a driver\'s license.',
    location: 'Cafeteria',
    date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    imageUrl: 'https://picsum.photos/seed/wallet/600/400',
    imageHint: 'leather wallet',
    contactName: 'Emily White',
    contactEmail: 'emily.white@campus.edu',
  },
];


export async function getItems(type?: 'lost' | 'found'): Promise<Item[]> {
  noStore();
  await new Promise(resolve => setTimeout(resolve, 100)); // Simulate network delay
  const items = await readItems();
  let filteredItems = items;
  if (type) {
    filteredItems = items.filter(item => item.type === type);
  }
  return filteredItems.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}

export async function getItem(id: string): Promise<Item | undefined> {
  noStore();
  await new Promise(resolve => setTimeout(resolve, 100));
  const items = await readItems();
  return items.find(item => item.id === id);
}

export async function addItem(item: Omit<Item, 'id' | 'date'>): Promise<Item> {
  noStore();
  await new Promise(resolve => setTimeout(resolve, 100));
  const items = await readItems();
  const newItem: Item = {
    ...item,
    id: crypto.randomUUID(),
    date: new Date().toISOString(),
  };
  const newItems = [newItem, ...items];
  await writeItems(newItems);
  return newItem;
}
