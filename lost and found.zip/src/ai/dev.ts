import { config } from 'dotenv';
config();

import '@/ai/flows/match-lost-and-found-items.ts';
import '@/ai/flows/generate-item-description.ts';