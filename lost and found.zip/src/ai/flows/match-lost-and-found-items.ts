'use server';
/**
 * @fileOverview Matches lost and found items based on description and location.
 *
 * - matchLostAndFoundItems - A function that handles the matching process.
 * - MatchLostAndFoundItemsInput - The input type for the matchLostAndFoundItems function.
 * - MatchLostAndFoundItemsOutput - The return type for the matchLostAndFoundItems function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const MatchLostAndFoundItemsInputSchema = z.object({
  lostItemDescription: z
    .string()
    .describe('The description of the lost item, including details like color, size, and any distinguishing features.'),
  lostItemLocation: z
    .string()
    .describe('The approximate location where the item was lost.'),
  foundItemDescription: z
    .string()
    .describe('The description of the found item, including details like color, size, and any distinguishing features.'),
  foundItemLocation: z
    .string()
    .describe('The location where the item was found.'),
});
export type MatchLostAndFoundItemsInput = z.infer<typeof MatchLostAndFoundItemsInputSchema>;

const MatchLostAndFoundItemsOutputSchema = z.object({
  matchLikelihood: z
    .string()
    .describe('The likelihood of a match between the lost and found items, expressed as a percentage.'),
  reasoning: z
    .string()
    .describe('The reasoning behind the match likelihood score, explaining why the items are likely or unlikely to be a match.'),
});
export type MatchLostAndFoundItemsOutput = z.infer<typeof MatchLostAndFoundItemsOutputSchema>;

export async function matchLostAndFoundItems(
  input: MatchLostAndFoundItemsInput
): Promise<MatchLostAndFoundItemsOutput> {
  return matchLostAndFoundItemsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'matchLostAndFoundItemsPrompt',
  input: {schema: MatchLostAndFoundItemsInputSchema},
  output: {schema: MatchLostAndFoundItemsOutputSchema},
  prompt: `You are an AI assistant designed to determine the likelihood of a match between a lost item and a found item.

Analyze the following information to assess the potential match:

Lost Item Description: {{{lostItemDescription}}}
Lost Item Location: {{{lostItemLocation}}}
Found Item Description: {{{foundItemDescription}}}
Found Item Location: {{{foundItemLocation}}}

Based on the descriptions and locations, determine the likelihood of a match. Provide a match likelihood score as a percentage and explain your reasoning.

Consider factors such as the similarity of the descriptions, the proximity of the locations, and any other relevant details.

Output the match likelihood and your reasoning in the specified JSON format.
`,
});

const matchLostAndFoundItemsFlow = ai.defineFlow(
  {
    name: 'matchLostAndFoundItemsFlow',
    inputSchema: MatchLostAndFoundItemsInputSchema,
    outputSchema: MatchLostAndFoundItemsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
